from pathlib import Path
import time, subprocess, json
B=Path(__file__).parent
for _ in range(7200):
 if (B/'state/selection.json').exists(): break
 time.sleep(1)
else: raise RuntimeError('Mask preparation did not complete in 2 hours')
rows=json.loads((B/'state/selection.json').read_text())
assert len(rows)==500
with (B/'generate.log').open('w') as log:
 subprocess.run(['/path/to/user-home/anaconda3/envs/snow-edit/bin/python','-u',str(B/'generate.py'),'--count','500'],stdout=log,stderr=subprocess.STDOUT,check=True)

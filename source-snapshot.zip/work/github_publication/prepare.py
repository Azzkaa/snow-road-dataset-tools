from pathlib import Path
import shutil,json,re,hashlib,subprocess
R=Path(__file__).resolve().parents[2];D=R/'outputs/github_publication';D.mkdir(exist_ok=True)
names=['snow-road-dataset-tools','road-inpainting-baselines','klein-road-restoration','road-lane-geometry','context-road-inpainting-hybrids'];titles=['Snow road dataset preparation','Road inpainting baselines','Klein road restoration fine-tuning','Road and lane geometry research','Context-aware road inpainting hybrids'];buckets={n:[] for n in names}
def group(p):
 s=str(p)
 if s.startswith('work/lane_geometry/compvis_hybrid/') or s.startswith('work/lane_geometry/hybrid/'):return names[4]
 if s.startswith('work/lane_geometry/'):
  return names[2] if 'klein' in p.name.lower() else names[3]
 if s.startswith('work/road_restoration/') or s.startswith('work/inpainting_compare/'):return names[1]
 return names[0]
# First-party top-level scripts and explicitly identified implementation directories only.
roots=[p for p in (R/'work').iterdir() if p.is_dir()];files=[]
for root in roots:
 files.extend(p for p in root.iterdir() if p.is_file())
for rel in ['work/lane_geometry/compvis_hybrid','work/lane_geometry/hybrid']:
 files.extend(p for p in (R/rel).iterdir() if p.is_file())
allowed={'.py','.sh','.md','.yaml','.yml','.toml'}
for p in files:
 if p.suffix.lower() not in allowed and not(p.name.startswith('requirements') and p.suffix=='.txt'):continue
 if p.stat().st_size>1000000:continue
 rel=p.relative_to(R);buckets[group(rel)].append(rel)
# Select concise evidence rather than dataset images or internal conversation handoffs.
extra={names[1]:['outputs/road_restoration/uqtr_metrics/image_quality_summary.json','outputs/road_restoration/professor_original/standalone_ldm.png','outputs/road_restoration/professor_original/standalone_lama.png','outputs/road_restoration/professor_original/direct.png'],names[2]:['outputs/lane_geometry/klein_requested_example/input_output_labelled.png','outputs/lane_geometry/klein_requested_prompted/input_output_labelled.png','outputs/lane_geometry/klein_paired_training/final_integrity.json'],names[4]:['outputs/lane_geometry/compvis_hybrid/EXPERIMENT_PLAN.md','outputs/lane_geometry/compvis_hybrid/CHANGELOG.md','outputs/lane_geometry/compvis_hybrid/architecture.png','outputs/lane_geometry/compvis_hybrid/lama_fallback/eval100/comparison_metrics.json','outputs/lane_geometry/compvis_hybrid/lama_fallback/correction/pilot100/comparison_metrics.json']}
for n,paths in extra.items():buckets[n].extend(Path(p) for p in paths if (R/p).exists())
findings=[];manifest={}
secret=re.compile(r'(?:sk-[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[0-9A-Z]{16}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----)')
for name,title in zip(names,titles):
 dest=D/name;dest.mkdir(exist_ok=True);entries=[]
 for rel in sorted(set(buckets[name])):
  src=R/rel;target=dest/rel;target.parent.mkdir(parents=True,exist_ok=True)
  if src.suffix=='.png':
   from PIL import Image
   Image.open(src).convert('RGB').save(target) # No embedded metadata in public examples.
  else:
   text=src.read_text(errors='strict')
   if secret.search(text):findings.append(str(rel));continue
   text=text.replace('/path/to/user-home','/path/to/user-home').replace('/path/to/external-media','/path/to/external-media');target.write_text(text)
  entries.append(dict(path=str(rel),sha256=hashlib.sha256(target.read_bytes()).hexdigest(),bytes=target.stat().st_size))
 overview='''Research snapshot, 26 November 2026. These are experimental scripts and selected evidence, not a production restoration system. Original project layout is preserved under `work/` and `outputs/`. Scripts depend on local model downloads, separate dataset manifests and historical directories; paths containing `/path/to/user-home` or `/path/to/external-media` must be configured. No clean reference is provided during deployment inference.\n\n'''
 status={names[0]:'Tools for synthetic snow preparation, pair management, review and integrity checks. Dataset images and annotations are not redistributed.',names[1]:'Original pretrained CompVis/Big LaMa comparisons and later LDM adapter training. Earlier LaMa+LDM runs trained the LDM stage, not LaMa. Examples are preliminary; lane geometry is unreliable.',names[2]:'Completed instructed Klein LoRA fine-tuning: 6,783 updates. Single-image inference examples remove snow but do not establish correct hidden lane recovery. Text-free and hybrid explorations are distinct experiments.',names[3]:'Road segmentation, lane/boundary supervision, evaluation and model audits. UQTR701 lane annotations are TRAIN-only and one geographic group. Teacher agreement is not independent accuracy.',names[4]:'CompVis-first followed by Big LaMa scene/sign-conditioned hybrids. CompVis pilots failed visually. LaMa20-case context LPIPS gains were below1%, below the5%extension rule; lane markings remain missing. A bounded decoder/lane-weight correction is recorded separately.'}[name]
 deps='\n## External models and data\nObtain upstream models and datasets separately under their original terms. No upstream weights, vendor repositories, environments, full datasets, credentials or optimizer checkpoints are included. See source imports and recorded provenance for exact dependencies. Third-party model licenses are not granted by this repository.\n'
 siblings='\n## Related repositories\n'+''.join('- https://github.com/sadad54/'+n+'\n' for n in names if n!=name)
 (dest/'README.md').write_text('# '+title+'\n\n'+overview+'## Recorded scope and limitations\n'+status+'\n'+deps+siblings+'\n## Snapshot integrity\n`PUBLICATION_MANIFEST.json` records the SHA-256 of included files. Source paths were anonymized in this public copy; originals remain unchanged. This snapshot does not establish complete reproduction on another machine.\n')
 (dest/'.gitignore').write_text('.env\n.env.*\n!.env.example\n.aws/\n.codex/\nvenv/\n.venv/\n__pycache__/\n*.pyc\n*.pt\n*.pth\n*.ckpt\n*.safetensors\n*.bin\nnode_modules/\n')
 (dest/'PUBLICATION_MANIFEST.json').write_text(json.dumps(dict(files=entries,excluded='datasets, annotations, pretrained weights, checkpoints, environments, secrets, internal handoffs; public text paths anonymized'),indent=2));manifest[name]=dict(files=len(entries),bytes=sum(e['bytes'] for e in entries))
(D/'inventory.json').write_text(json.dumps(manifest,indent=2));(D/'secret_scan_findings_LOCAL_ONLY.json').write_text(json.dumps(findings));print(json.dumps(dict(repositories=manifest,secret_findings_count=len(findings)),indent=2))

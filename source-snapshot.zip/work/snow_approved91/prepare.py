from pathlib import Path
import json,hashlib,shutil
from PIL import Image
B=Path(__file__).parent;S=B/'state';A=Path('/path/to/user-home/Desktop/snow_masks_for_approval_91');D=Path('/path/to/user-home/Desktop/snowy_approved_masks_91')
assert not D.exists(),'Refusing to overwrite a previous output folder'
D.mkdir()
for d in ['inputs','masks','mask_previews','raw','metadata']:(S/d).mkdir(parents=True,exist_ok=True)
approved=json.loads((A/'approval_manifest.json').read_text());plan=json.loads((B.parent/'mask_review91/plan.json').read_text());assert len(approved)==len(plan)==91
rows=[]
for n,(a,p) in enumerate(zip(approved,plan),1):
 assert a['review_number']==n and a['source']==p['source']
 mask=A/a['mask'];digest=hashlib.sha256(mask.read_bytes()).hexdigest();assert digest==a['mask_sha256'],f'Mask changed since last review: {n}'
 assert hashlib.sha256(Path(p['source']).read_bytes()).hexdigest()==p['source_sha256']
 shutil.copy2(mask,S/'masks'/f'{n:03d}.png');shutil.copy2(A/a['preview'],S/'mask_previews'/f'{n:03d}.jpg')
 im=Image.open(p['source']).convert('RGB').resize(tuple(p['generation_dimensions']),Image.Resampling.LANCZOS);im.save(S/'inputs'/f'{n:03d}.png')
 r=dict(p,index=n,seed=202611140000+n,conditioning=f'inputs/{n:03d}.png',ground_mask=f'masks/{n:03d}.png',approved_mask_sha256=digest,approved_mask_review_number=n,conditioning_paint_removed_pixels=0)
 rows.append(r)
shutil.copy2(B.parent/'snow_replacements820/prompt.txt',S/'prompt.txt');shutil.copy2(B.parent/'snow_replacements820/state/prompt_embeds.pt',S/'prompt_embeds.pt')
(S/'selection.json').write_text(json.dumps(rows,indent=2));(S/'approved_mask_snapshot.json').write_text(json.dumps(approved,indent=2))
status=dict(status='all_91_masks_approved_snow_generation_authorized',approved_mask_numbers=list(range(1,92)),pending_mask_numbers=[],snow_generation_authorized=True,approval_source='User explicitly approved final masks and requested snowy generation on 2026-11-14',snow_output_folder=str(D))
(A/'approval_status.json').write_text(json.dumps(status,indent=2));(S/'approval.json').write_text(json.dumps(status,indent=2))
print('Frozen and hash-verified all 91 approved masks. Output:',D)

from pathlib import Path
import time,subprocess,json,traceback
B=Path(__file__).parent
try:
 for _ in range(3600):
  if (B/'state/selection.json').exists():break
  if _%5==0:(B/'prepare.log').write_text(f'Loading approved masks and conditioning: {len(list((B/"state/inputs").glob("*.png")))}/91\n')
  time.sleep(1)
 else:raise RuntimeError('Approved-mask preparation did not finish')
 assert len(json.loads((B/'state/selection.json').read_text()))==91
 with (B/'generate.log').open('w') as log:
  subprocess.run(['/path/to/user-home/anaconda3/envs/snow-edit/bin/python','-u',str(B/'generate.py'),'--count','91'],stdout=log,stderr=subprocess.STDOUT,check=True)
except Exception:
 (B/'failure.txt').write_text(traceback.format_exc());raise

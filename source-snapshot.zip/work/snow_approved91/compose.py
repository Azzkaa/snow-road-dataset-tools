from pathlib import Path
import json,argparse,hashlib
import numpy as np
from PIL import Image,ImageFilter
B=Path(__file__).parent;S=B/'state';D=Path('/path/to/user-home/Desktop/snowy_approved_masks_91')
p=argparse.ArgumentParser();p.add_argument('--index',type=int,required=True);n=p.parse_args().index
r=json.loads((S/'selection.json').read_text())[n-1]
assert json.loads((S/'approval.json').read_text())['snow_generation_authorized']
maskfile=S/r['ground_mask'];assert hashlib.sha256(maskfile.read_bytes()).hexdigest()==r['approved_mask_sha256']
clean=Image.open(r['source']).convert('RGB');mask=Image.open(maskfile).convert('L');assert mask.size==clean.size
original=np.array(clean);allowed=np.array(mask)>0
alpha=np.array(mask.filter(ImageFilter.GaussianBlur(max(1,clean.width/1024))),dtype='float32')/255;alpha[~allowed]=0
raw=Image.open(S/'raw'/f'{n:03d}.png').convert('RGB');gen=np.array(raw.resize(clean.size,Image.Resampling.LANCZOS))
final=np.rint(alpha[...,None]*gen+(1-alpha[...,None])*original).clip(0,255).astype('uint8');final[~allowed]=original[~allowed]
dest=D/r['output_name'];Image.fromarray(final).save(dest,compress_level=1)
saved=np.array(Image.open(dest));assert not np.any(saved[~allowed]!=original[~allowed])
q=dict(index=n,file=str(dest),source=r['source'],dimensions=list(clean.size),approved_mask_sha256=r['approved_mask_sha256'],approved_mask_unchanged=True,outside_mask_changed_pixels=0,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),status='generated_with_approved_mask_pending_output_review')
(S/'metadata'/f'{n:03d}_qa.json').write_text(json.dumps(q,indent=2));count=len(list(D.glob('*_snowy.png')))
(S/'progress.json').write_text(json.dumps(dict(target=91,generated=count,current=n,stage='complete_pending_output_review' if count==91 else 'generating_with_approved_masks'),indent=2))
print('Saved',count,'/91',dest.name,flush=True)

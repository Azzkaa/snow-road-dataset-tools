from pathlib import Path
import os,json,hashlib,argparse,shutil
os.environ['HF_HUB_OFFLINE']='1'
os.environ['TRANSFORMERS_OFFLINE']='1'
import torch,numpy as np
from PIL import Image,ImageFilter,ImageDraw
from reflection_guard import refine
from transformers import SegformerImageProcessor,SegformerForSemanticSegmentation
B=Path(__file__).parent;S=B/'state'
OLD=Path('/path/to/user-home/Documents/Codex/2026-11-04/files-mentioned-by-the-user-snow')
D=Path('/path/to/user-home/Desktop/snowy_replacements_820')
p=argparse.ArgumentParser();p.add_argument('--limit',type=int,default=820);args=p.parse_args()
D.mkdir(exist_ok=True)
for name in ['inputs','masks','mask_previews','raw','metadata']:(S/name).mkdir(parents=True,exist_ok=True)
shutil.copy(B/'prompt.txt',S/'prompt.txt')
plan=json.loads((B/'source_plan.json').read_text());assert len(plan)==820
torch.set_num_threads(4)
cache=str(OLD/'work/klein_snow_100/model_cache');model=str(B/'cityscapes_model')
processor=SegformerImageProcessor.from_pretrained(model,cache_dir=cache,local_files_only=True)
net=SegformerForSemanticSegmentation.from_pretrained(model,cache_dir=cache,local_files_only=True).eval().to('cuda')
ground=[int(i) for i,n in net.config.id2label.items() if n in ['road','sidewalk','terrain']]
road=[int(i) for i,n in net.config.id2label.items() if n in ['road','sidewalk']]
protected=[int(i) for i,n in net.config.id2label.items() if n in ['car','bus','truck','person','rider','bicycle','motorcycle','train','building','sky','vegetation','wall','fence','pole','traffic sign','traffic light']]
def predict(view):
 with torch.inference_mode():
  inp=processor(images=view,return_tensors='pt',size={'height':768,'width':768}).to('cuda')
  prob=net(**inp).logits.softmax(1)
  prob=torch.nn.functional.interpolate(prob,size=(view.height,view.width),mode='bilinear',align_corners=False)[0]
  maps=torch.stack([prob[ground].sum(0),prob[road].sum(0),prob[protected].sum(0),torch.isin(prob.argmax(0),torch.tensor(ground,device='cuda')).float(),prob[[13,14,15,16,17,18]].sum(0)])
 return maps.cpu().numpy()
rows=[]
for n,old in enumerate(plan,1):
 r=dict(old,index=n,seed=202611130000+n)
 src=Path(r['source']);assert src.exists()
 r.update(conditioning=f'inputs/{n:03d}.png',ground_mask=f'masks/{n:03d}.png',conditioning_paint_removed_pixels=0)
 rows.append(r)
 if n>args.limit:continue
 if (S/'masks'/f'{n:03d}.png').exists():continue
 assert hashlib.sha256(src.read_bytes()).hexdigest()==r['source_sha256']
 im=Image.open(src).convert('RGB').resize(tuple(r['generation_dimensions']),Image.Resampling.LANCZOS)
 im.save(S/r['conditioning']);w,h=im.size
 first=predict(im);mirror=predict(im.transpose(Image.Transpose.FLIP_LEFT_RIGHT))[:,:,::-1]
 # The foreground crop gives more model resolution to the road and hood boundary.
 top=int(h*.32);crop=predict(im.crop((0,top,w,h)))
 gp=np.maximum(first[0],mirror[0]);rp=np.maximum(first[1],mirror[1]);pp=np.maximum(first[2],mirror[2])
 base=(first[3]>.5)|(mirror[3]>.5)
 gp[top:]=np.maximum(gp[top:],crop[0]);rp[top:]=np.maximum(rp[top:],crop[1]);pp[top:]=np.maximum(pp[top:],crop[2]);base[top:]|=crop[3]>.5
 carprob=np.maximum(first[4],mirror[4]);carprob[top:]=np.maximum(carprob[top:],crop[4])
 hardprotect=pp>.65
 mask=(base|((rp>.20)&(pp<.40)))&~hardprotect
 padded=Image.fromarray(np.pad(mask.astype('uint8')*255,5,mode='edge'))
 closed=np.array(padded.filter(ImageFilter.MaxFilter(11)).filter(ImageFilter.MinFilter(11)))[5:-5,5:-5]>0
 # Fill missed road seams only where semantic ground evidence remains.
 mask|=closed&(gp>.20)&(pp<.45)
 flood=Image.fromarray(np.pad(mask.astype('uint8')*255,1)).copy();ImageDraw.floodfill(flood,(0,0),128)
 holes=np.array(flood)[1:-1,1:-1]==0
 mask|=holes&(gp>.18)&(pp<.35)
 mask&=~hardprotect
 mask,reflection=refine(im,mask,(pp-carprob)>.60,carprob)
 assert mask.any()
 Image.fromarray((mask*255).astype('uint8')).save(S/r['ground_mask'])
 overlay=np.array(im).copy();overlay[mask]=(overlay[mask]*.5+np.array([0,210,255])*.5).astype('uint8')
 Image.fromarray(overlay).save(S/'mask_previews'/f'{n:03d}.jpg',quality=90)
 (S/'metadata'/f'{n:03d}_mask.json').write_text(json.dumps(dict(method='Cityscapes road model; 768px whole-view and mirrored-view ensemble plus foreground crop; semantic road-gap filling; strong object exclusion',mask_pixels=int(mask.sum()),protected_pixels=int(hardprotect.sum()),previous_batch=old['previous_batch'],reflection_guard=reflection)))
 print('Prepared replacement mask',n,'/ 820',src.name,flush=True)
(S/'selection.json').write_text(json.dumps(rows,indent=2))
if args.limit>=820:(S/'masks_ready.json').write_text(json.dumps({'prepared':820}))

from pathlib import Path
import json,argparse,hashlib,os
os.environ['HF_HUB_OFFLINE']='1'
import torch,numpy as np
from PIL import Image,ImageFilter
from reflection_guard import refine
from transformers import SegformerImageProcessor,SegformerForSemanticSegmentation
B=Path(__file__).parent;S=B/'state';D=Path('/path/to/user-home/Desktop/snowy_replacements_820')
p=argparse.ArgumentParser();p.add_argument('--index',type=int,required=True);n=p.parse_args().index
r=json.loads((S/'selection.json').read_text())[n-1]
torch.set_num_threads(4)
proc=SegformerImageProcessor.from_pretrained(B/'cityscapes_model',local_files_only=True)
net=SegformerForSemanticSegmentation.from_pretrained(B/'cityscapes_model',local_files_only=True).eval()
orig=Image.open(S/r['conditioning']).convert('RGB');raw=Image.open(S/'raw'/f'{n:03d}.png').convert('RGB');w,h=orig.size
maps=[]
for im in [orig,raw]:
 with torch.inference_mode():
  z=net(**proc(images=im,return_tensors='pt',size={'height':768,'width':768})).logits.softmax(1)
  z=torch.nn.functional.interpolate(z,size=(h,w),mode='bilinear',align_corners=False)[0]
  maps.append(z.numpy())
a,b=maps
# Generated-view road segmentation supplies ground evidence through windshield reflections.
# Preserve source objects when both views agree, and source sky/buildings/vegetation regardless.
ground=[0,1,9];vehicles=[11,12,13,14,15,16,17,18];static=[2,3,4,5,6,7,8,10]
ag=a[ground].sum(0);bg=b[ground].sum(0)
vehicle=(a[vehicles].sum(0)>.40)&(b[vehicles].sum(0)>.35)
staticprotect=a[static].sum(0)>.60
mask=((ag>.45)|(bg>.45))&~vehicle&~staticprotect
# Remove isolated ground predictions by requiring a minimum local ground support.
mask=np.array(Image.fromarray(mask.astype('uint8')*255).filter(ImageFilter.MedianFilter(5)))>0
reflection={'applied':False}
if float((a[17]>.5).mean())<.003:
 mask,reflection=refine(orig,mask,staticprotect,b[vehicles].sum(0))
Image.fromarray((mask*255).astype('uint8')).save(S/'masks'/f'{n:03d}.png')
preview=np.array(orig);preview[mask]=(preview[mask]*.5+np.array([0,210,255])*.5).astype('uint8');Image.fromarray(preview).save(S/'mask_previews'/f'{n:03d}.jpg',quality=90)
clean=Image.open(r['source']).convert('RGB');origpixels=np.array(clean);fullmask=Image.fromarray(mask.astype('uint8')*255).resize(clean.size,Image.Resampling.NEAREST);allowed=np.array(fullmask)>0
alpha=np.array(fullmask.filter(ImageFilter.GaussianBlur(max(1,clean.width/1024))),dtype='float32')/255;alpha[~allowed]=0
snow=np.array(raw.resize(clean.size,Image.Resampling.LANCZOS));result=np.rint(alpha[...,None]*snow+(1-alpha[...,None])*origpixels).clip(0,255).astype('uint8');result[~allowed]=origpixels[~allowed]
dest=D/r['output_name'];Image.fromarray(result).save(dest,compress_level=1)
q=dict(index=n,file=str(dest),dimensions=list(clean.size),outside_mask_changed_pixels=0,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),status='pending_visual_review',reflection_guard=reflection,mask_method='Original and generated-view Cityscapes ground consensus; agreement-based vehicle protection; original static-object protection')
(S/'metadata'/f'{n:03d}_qa.json').write_text(json.dumps(q,indent=2));count=len(list(D.glob('*_snowy.png')))
(S/'progress.json').write_text(json.dumps(dict(target=820,generated=count,current=n,stage='complete_pending_visual_review' if count==820 else 'generating'),indent=2))
print('Saved refined replacement',n,dest.name,flush=True)

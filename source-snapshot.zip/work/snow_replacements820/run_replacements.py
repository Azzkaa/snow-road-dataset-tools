from pathlib import Path
import subprocess,json,traceback
B=Path(__file__).parent;PY='/path/to/user-home/anaconda3/envs/snow-edit/bin/python'
try:
 with (B/'prepare.log').open('w') as log:
  subprocess.run([PY,'-u',str(B/'prepare.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
 assert json.loads((B/'state/masks_ready.json').read_text())['prepared']==820
 with (B/'generate.log').open('w') as log:
  subprocess.run([PY,'-u',str(B/'generate.py'),'--count','820'],stdout=log,stderr=subprocess.STDOUT,check=True)
except Exception:
 (B/'failure.txt').write_text(traceback.format_exc());raise

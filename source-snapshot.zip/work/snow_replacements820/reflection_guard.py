import numpy as np
from PIL import Image,ImageDraw

def refine(im,mask,protected,carprob):
 a=np.array(im).astype('float32');h,w=mask.shape
 gray=a.mean(2);strip=gray[:,int(w*.2):int(w*.75)]
 row=np.median(strip,axis=1);smooth=np.convolve(row,np.ones(5)/5,mode='same')
 lo,hi=int(h*.76),int(h*.94)
 gradient=smooth[:-4]-smooth[4:]
 y=int(np.argmax(gradient[lo:hi])+lo+2)
 strength=float(gradient[y-2]);y=max(0,y-round(h*.012))
 # Act only on a distinct dark horizontal dashboard/wiper boundary near the bottom.
 if strength<9 or float(np.median(gray[int(h*.94):]))>115:return mask,{'applied':False}
 # Retain cars connected to the main scene. Bottom-only car predictions are often reflections.
 vehicles=carprob>.45
 keep=np.zeros_like(mask)
 # Keep vertically continuous vehicle silhouettes from the scene, but reject
 # separate low predictions caused by reflections of those vehicles.
 for ix in range(w):
  col=vehicles[:,ix].copy();changes=np.diff(np.r_[False,col,False].astype('int8'))
  starts=np.nonzero(changes==1)[0];ends=np.nonzero(changes==-1)[0]
  for begin,end in zip(starts,ends):
   if begin<h*.64:keep[begin:end,ix]=True
 # Use the already segmented road corridor to bridge reflection gaps before the windshield edge.
 refined=mask.copy()
 start=int(h*.66)
 for iy in range(start,min(y,h)):
  band=mask[max(0,iy-45):iy+1]
  columns=np.any(band,axis=0);xs=np.nonzero(columns)[0]
  if len(xs):refined[iy,xs.min():xs.max()+1]=True
 refined[:start]&=~protected[:start];refined[keep]=False
 refined[y:]=False
 return refined,{'applied':True,'windshield_bottom_y':y,'edge_strength':strength}

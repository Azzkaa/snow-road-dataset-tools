from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from html import escape
from urllib.parse import urlsplit
import json,time,io
from datetime import datetime
from zoneinfo import ZoneInfo
from PIL import Image

B=Path(__file__).parent
S=B/'state'
D=Path('/path/to/user-home/Desktop/klein_snow_batch5_2001-2500')

def snapshot():
    items=[]
    for p in (S/'metadata').glob('*_qa.json'):
        try:
            q=json.loads(p.read_text())
            if Path(q['file']).exists(): items.append((p.stat().st_mtime,q))
        except (OSError,ValueError,KeyError): pass
    items.sort(key=lambda x:x[0])
    count=len(items)
    latest=items[-1][1] if items else None
    log=B/'generate.log'
    updated=log.stat().st_mtime if log.exists() else 0
    active=time.time()-updated<90
    tail=log.read_text(errors='replace').splitlines()[-8:] if log.exists() else []
    failed=any('Traceback' in x or 'Error:' in x for x in tail)
    status='Generated — visual review pending' if count==500 else 'Generation error' if failed else 'Generating' if active else 'No recent activity — check required'
    seconds=(items[-1][0]-items[0][0])/(count-1) if count>1 else None
    eta=f'About {round((500-count)*seconds/60)} min remaining' if seconds and active and count<500 else 'Calculating…' if count<500 else 'Generation complete'
    if not log.exists():
        prep=B/'prepare.log'
        prepared=len(list((S/'masks').glob('*.png')))
        active=prep.exists() and time.time()-prep.stat().st_mtime<120
        status=f'Preparing improved road masks: {prepared} / 500' if active else 'Mask preparation needs attention'
        eta='Snow generation starts after mask checks'
        tail=prep.read_text(errors='replace').splitlines()[-8:] if prep.exists() else []
    return count,latest,status,eta,tail,active

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def do_GET(self):
        path=urlsplit(self.path).path
        if path not in ['/','/preview','/original']:
            self.send_error(404);return
        count,latest,status,eta,tail,active=snapshot()
        previews=sorted((S/'mask_previews').glob('*.jpg'))
        preparing=not latest
        display_count=len(previews) if preparing else count
        phase='masks prepared' if preparing else 'snowy images saved'
        if path in ['/preview','/original']:
            if preparing:
                if not previews: self.send_error(404);return
                source=previews[-1] if path=='/preview' else S/'inputs'/(previews[-1].stem+'.png')
            else:
                source=Path(latest['file'])
            if path=='/original' and not preparing:
                rows=json.loads((S/'selection.json').read_text())
                source=Path(rows[latest['index']-1]['source'])
            im=Image.open(source).convert('RGB');im.thumbnail((1100,750))
            out=io.BytesIO();im.save(out,format='JPEG',quality=88)
            data=out.getvalue();mime='image/jpeg'
        else:
            now=datetime.now(ZoneInfo('Asia/Riyadh')).strftime('%H:%M:%S')
            name=escape(Path(latest['file']).name) if latest else ('Mask '+previews[-1].stem+' · cyan shows the editable ground' if previews else 'Preparing first mask')
            preview_label='Road mask · cyan overlay' if preparing else 'Snowy · visual review pending'
            detail=f'<div class="pair"><figure><img src="/original?t={count}" alt="Original summer source"><figcaption>Original</figcaption></figure><figure><img src="/preview?t={count}" alt="Latest saved snowy image"><figcaption>{preview_label}</figcaption></figure></div>' if latest or previews else ''
            data=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="5"><title>Live snow batch progress</title><style>
            :root{{color-scheme:dark light;font-family:system-ui,sans-serif;background:#101820;color:#ecf3f7}}body{{max-width:1200px;margin:0 auto;padding:30px 24px}}h1{{font-size:25px;font-weight:500;margin:0 0 8px}}.muted{{color:#aebfca}}.number{{font-size:48px;font-variant-numeric:tabular-nums;margin:26px 0 10px}}progress{{width:100%;height:18px;accent-color:#86d9d0}}.line{{display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;margin:12px 0}}.pair{{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:24px 0}}figure{{margin:0}}img{{width:100%;aspect-ratio:16/10;object-fit:contain;background:#18232d}}figcaption{{margin-top:8px;color:#aebfca}}code,pre{{overflow-wrap:anywhere;white-space:pre-wrap}}pre{{font-size:12px;color:#aebfca}}@media(max-width:680px){{.pair{{grid-template-columns:1fr}}body{{padding:20px 16px}}}}
            </style></head><body><h1>Snow batch 5 · FLUX.2 Klein 4B</h1><div class="muted">Batch 5 · improved road coverage masks · refreshes every 5 seconds</div>
            <main aria-live="polite"><div class="number">{display_count} <span class="muted">/ 500</span></div><progress value="{display_count}" max="500" aria-label="{phase}"></progress><div class="line"><span>{escape(status)} · {display_count/5:.1f}% · {phase}</span><span>{escape(eta)}</span></div>
            <div class="muted">Latest preview: <code>{name}</code></div>{detail}</main><div class="muted">Desktop / klein_snow_batch5_2001-2500</div><p class="muted">Saved images are counted from export records. The prompt requires lane paint to be buried under snow; generation progress does not certify visual review.</p><details><summary>Recent generation activity</summary><pre>{escape(chr(10).join(tail))}</pre></details><p class="muted">Updated {now} · Riyadh time</p></body></html>'''.encode()
            mime='text/html; charset=utf-8'
        self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)

server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
url=f'http://127.0.0.1:{server.server_port}'
(B/'progress_url.txt').write_text(url)
print(url,flush=True)
server.serve_forever()

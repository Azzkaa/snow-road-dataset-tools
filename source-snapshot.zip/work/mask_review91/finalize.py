from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
D=Path('/path/to/user-home/Desktop/snow_masks_for_approval_91')
# Local road-only corrections identified in the visual mask review. All are clipped
# to the individually drafted windshield boundary.
fills={
 14:[[(.44,.76),(.57,.76),(.60,.83),(.44,.83)]],
 17:[[(.02,.72),(.14,.68),(.31,.83),(.29,.88),(.04,.84)]],
 32:[[(.12,.70),(.27,.70),(.48,.80),(.44,.84),(.17,.82)]],
 38:[[(.38,.66),(.57,.64),(.69,.80),(.49,.82),(.39,.76)]],
 40:[[(.68,.68),(.80,.68),(.82,.75),(.68,.75)]],
 67:[[(.31,.65),(.49,.60),(.56,.72),(.31,.73)]],
 74:[[(.40,.52),(.74,.51),(.80,.66),(.44,.67)]],
 75:[[(.46,.61),(.65,.61),(.73,.75),(.48,.76)]],
 78:[[(.13,.63),(.29,.53),(.39,.57),(.43,.75),(.31,.83),(.12,.83)]]
}
records=sorted([json.loads(p.read_text()) for p in (D/'metadata').glob('*.json')],key=lambda r:r['review_number'])
assert len(records)==91
ledger=[]
for r in records:
 p=D/r['mask'];full=Image.open(p).convert('L');W,H=full.size
 im=Image.open(D/r['original']).convert('RGB');w,h=im.size
 m=full.resize((w,h),Image.Resampling.NEAREST)
 # Eliminate disconnected upper-frame false positives, such as sun-visor/sky specks.
 tiny=m.copy();tiny.thumbnail((256,256),Image.Resampling.NEAREST);a=np.array(tiny);canvas=Image.fromarray(a).copy();remove=np.zeros_like(a,dtype=bool)
 for _ in range(300):
  arr=np.array(canvas);ys,xs=np.nonzero(arr==255)
  if not len(ys):break
  ImageDraw.floodfill(canvas,(int(xs[0]),int(ys[0])),128)
  part=(arr==255)&(np.array(canvas)==128);py,px=np.nonzero(part)
  if len(py) and py.max()<a.shape[0]*.5:remove|=part
  arr=np.array(canvas);arr[arr==128]=0;canvas=Image.fromarray(arr).copy()
 cut=np.array(Image.fromarray(remove.astype('uint8')*255).resize((w,h),Image.Resampling.NEAREST))>0
 mask=np.array(m);mask[cut]=0;m=Image.fromarray(mask)
 draw=ImageDraw.Draw(m)
 for poly in fills.get(r['review_number'],[]):draw.polygon([(round(x*w),round(y*h)) for x,y in poly],fill=255)
 cap=Image.new('L',(w,h),0);ImageDraw.Draw(cap).polygon([(0,0),(w,0)]+[(round(x*w),round(y*h)) for x,y in reversed(r['windshield_boundary_normalized'])],fill=255)
 mask=np.array(m)>0;mask&=np.array(cap)>0
 final=Image.fromarray(mask.astype('uint8')*255).resize((W,H),Image.Resampling.NEAREST);final.save(p)
 a=np.array(im);a[mask]=(a[mask]*.5+np.array([0,210,255])*.5).astype('uint8');Image.fromarray(a).save(D/r['preview'],quality=93)
 assert final.size==tuple(r['dimensions']) and np.any(mask)
 r['mask_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();r['manual_road_fill_polygons']=fills.get(r['review_number'],[]);r['snow_generated']=False
 metadata=D/'metadata'/(Path(r['source']).stem+'.json');metadata.write_text(json.dumps(r,indent=2));ledger.append(r)
(D/'approval_manifest.json').write_text(json.dumps(ledger,indent=2))
(D/'approval_status.json').write_text(json.dumps(dict(status='awaiting_user_mask_approval',snow_generation_authorized=False,target=91,masks_ready=91,snow_images_generated=0),indent=2))
print('Verified 91 mask dimensions and hashes; zero new snow images; awaiting explicit user approval.')

from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit,parse_qs,unquote,quote
from html import escape
import json,mimetypes
B=Path(__file__).parent/'revision3';D=Path('/path/to/user-home/Desktop/snow_masks_for_approval_91')
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  url=urlsplit(self.path)
  if url.path!='/':
   p=(D/unquote(url.path).lstrip('/')).resolve()
   if not p.is_relative_to(D.resolve()) or not p.is_file():self.send_error(404);return
   data=p.read_bytes();mime=mimetypes.guess_type(str(p))[0] or 'application/octet-stream'
  else:
   records=[]
   for p in (D/'metadata').glob('*.json'):
    try:records.append(json.loads(p.read_text()))
    except ValueError:pass
   records.sort(key=lambda r:r['review_number']);records=[r for r in records if r['review_number'] in [13,33,78]]
   total=len(records);wanted=int(parse_qs(url.query).get('n',['13'])[0]);pos=next((i for i,r in enumerate(records) if r['review_number']==wanted),0);r=records[pos] if records else None;num=r['review_number'] if r else 13;previous=records[max(0,pos-1)]['review_number'] if records else 13;following=records[min(total-1,pos+1)]['review_number'] if records else 13
   nav=' '.join(f'<a class="num {"selected" if x["review_number"]==num else ""}" href="/?n={x["review_number"]}">{x["review_number"]:02d}</a>' for x in records)
   content='Masks are preparing…'
   if r:
    name=escape(Path(r['source']).stem)
    content=f'<div class="line"><a href="/?n={previous}">← Previous</a><strong>Mask {num:02d} · revised</strong><a href="/?n={following}">Next →</a></div><p class="filename">{name}</p><div class="pair"><figure><img src="/{quote(r["original"])}"><figcaption>Original clean image</figcaption></figure><figure><img src="/{quote(r["preview"])}"><figcaption>Cyan = proposed snow-edit area · <a href="/{quote(r["mask"])}">Open full-size binary mask</a></figcaption></figure></div>'
   refresh='<meta http-equiv="refresh" content="10">' if total<3 else ''
   data=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">{refresh}<title>3 revised masks awaiting approval</title><style>body{{font:16px system-ui;background:#101820;color:#eef4f8;margin:0 auto;padding:28px;max-width:1500px}}h1{{font-weight:500}}a{{color:#83dfd4}}.notice{{color:#f6d68e}}.pair{{display:grid;grid-template-columns:1fr 1fr;gap:16px}}figure{{margin:0}}img{{width:100%;max-height:75vh;object-fit:contain;background:#16232c}}figcaption{{padding:8px 0;color:#acbeca}}.line{{display:flex;justify-content:space-between;gap:16px;margin:24px 0 8px}}.filename{{overflow-wrap:anywhere;color:#acbeca}}nav{{display:flex;gap:7px;flex-wrap:wrap;margin-top:24px}}.num{{padding:8px;text-decoration:none;background:#20313c;border-radius:4px}}.selected{{background:#83dfd4;color:#101820}}@media(max-width:800px){{.pair{{grid-template-columns:1fr}}body{{padding:16px}}}}</style></head><body><h1>Recheck 3 revised masks</h1><p class="notice">Awaiting your approval. No new snow images have been generated or queued.</p><p>3 side-line masks revised. The other 88 mask files are unchanged and recorded as approved. Review the cyan coverage and approve or identify remaining adjustments in the chat.</p>{content}<nav aria-label="Choose mask">{nav}</nav></body></html>'''.encode();mime='text/html; charset=utf-8'
  self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);url=f'http://127.0.0.1:{server.server_port}/';(B/'review_url.txt').write_text(url);print(url,flush=True);server.serve_forever()

from pathlib import Path
import json,os,hashlib
os.environ['HF_HUB_OFFLINE']='1'
import torch,numpy as np
from PIL import Image,ImageDraw,ImageFilter
from transformers import SegformerImageProcessor,SegformerForSemanticSegmentation
B=Path(__file__).parent;OLD=B.parent/'snow_replacements820'
D=Path('/path/to/user-home/Desktop/snow_masks_for_approval_91')
for name in ['masks','previews','originals','metadata']:(D/name).mkdir(parents=True,exist_ok=True)
rows=json.loads((B/'plan.json').read_text());bounds=json.loads((B/'windshield_boundaries.json').read_text())
(D/'approval_status.json').write_text(json.dumps(dict(status='awaiting_user_mask_approval',snow_generation_authorized=False,target=91)))
(D/'selection.json').write_text(json.dumps(rows,indent=2))
torch.set_num_threads(4)
proc=SegformerImageProcessor.from_pretrained(OLD/'cityscapes_model',local_files_only=True)
net=SegformerForSemanticSegmentation.from_pretrained(OLD/'cityscapes_model',local_files_only=True).eval().to('cuda')
def predict(im):
 with torch.inference_mode():
  z=net(**proc(images=im,return_tensors='pt',size={'height':768,'width':768}).to('cuda')).logits.softmax(1)
  z=torch.nn.functional.interpolate(z,size=(im.height,im.width),mode='bilinear',align_corners=False)[0]
  return torch.stack([z[[0,1,9]].sum(0),z[[11,12,13,14,15,16,17,18]].sum(0),z[[2,3,4,5,6,7,8,10]].sum(0),z[17]]).cpu().numpy()
for n,r in enumerate(rows,1):
 stem=Path(r['source']).stem;clean=Image.open(r['source']).convert('RGB');size=clean.size
 im=clean.resize(tuple(r['generation_dimensions']),Image.Resampling.LANCZOS);w,h=im.size
 original=predict(im);mirror=predict(im.transpose(Image.Transpose.FLIP_LEFT_RIGHT))[:,:,::-1]
 # This reads the previous raw result only for mask evidence; no snow generation occurs.
 previous=Image.open(OLD/'state/raw'/f'{r["index"]:03d}.png').convert('RGB').resize((w,h),Image.Resampling.LANCZOS)
 generated=predict(previous)
 ground=np.maximum(np.maximum(original[0],mirror[0]),generated[0])
 og=(original+mirror)/2
 vehicles=(og[1]>.45)&(generated[1]>.45)
 # Drop isolated low vehicle predictions caused by dashboard reflections.
 if float((og[3]>.4).mean())<.003:
  components=Image.fromarray(vehicles.astype('uint8')*255).copy()
  kept=np.zeros_like(vehicles)
  for _ in range(200):
   arr=np.array(components);ys,xs=np.nonzero(arr==255)
   if not len(ys):break
   ImageDraw.floodfill(components,(int(xs[0]),int(ys[0])),128)
   part=(arr==255)&(np.array(components)==128)
   if np.nonzero(part)[0].min()<h*.58:kept|=part
   arr=np.array(components);arr[arr==128]=0;components=Image.fromarray(arr).copy()
  vehicles=kept
 static=(og[2]>.70)&(generated[2]>.40)
 mask=ground>.35
 maskim=Image.fromarray(mask.astype('uint8')*255)
 mask=np.array(maskim.filter(ImageFilter.MaxFilter(7)).filter(ImageFilter.MinFilter(7)))>0
 flood=Image.fromarray(np.pad(mask.astype('uint8')*255,1)).copy();ImageDraw.floodfill(flood,(0,0),128)
 holes=np.array(flood)[1:-1,1:-1]==0
 mask|=holes
 mask&=~vehicles&~static
 boundary=bounds[str(n)]
 cap=Image.new('L',(w,h),0);ImageDraw.Draw(cap).polygon([(0,0),(w,0)]+[(round(x*w),round(y*h)) for x,y in reversed(boundary)],fill=255)
 mask&=np.array(cap)>0
 # The cap is per image, not a rectangular global cutoff or an automatically inferred wiper row.
 outmask=Image.fromarray(mask.astype('uint8')*255).resize(size,Image.Resampling.NEAREST)
 outmask.save(D/'masks'/(stem+'_mask.png'))
 preview=np.array(im);preview[mask]=(preview[mask]*.5+np.array([0,210,255])*.5).astype('uint8')
 Image.fromarray(preview).save(D/'previews'/(stem+'_mask_preview.jpg'),quality=93)
 im.save(D/'originals'/(stem+'.jpg'),quality=93)
 record=dict(review_number=n,source=r['source'],source_sha256=r['source_sha256'],mask='masks/'+stem+'_mask.png',preview='previews/'+stem+'_mask_preview.jpg',original='originals/'+stem+'.jpg',dimensions=size,windshield_boundary_normalized=boundary,method='Original/mirrored road segmentation plus prior raw ground evidence; enclosed-hole fill; static/vehicle exclusion; individually drafted windshield boundary',status='awaiting_user_approval',snow_generated=False)
 (D/'metadata'/(stem+'.json')).write_text(json.dumps(record,indent=2))
 print('MASK ONLY',n,'/91',stem,flush=True)
(D/'verification.json').write_text(json.dumps(dict(masks=len(list((D/'masks').glob('*.png'))),previews=len(list((D/'previews').glob('*.jpg'))),snow_images_generated=0,approval_required=True)))

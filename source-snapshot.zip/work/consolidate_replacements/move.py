from pathlib import Path
import os,json
B=Path('/path/to/user-home/Desktop');D=B/'snowy_images';W=Path('/path/to/user-home/Documents/Codex/2026-11-11/oka/work')
sources=[B/'snowy_replacements_820',B/'snowy_approved_masks_91']
existing={p.name for p in D.glob('*_snowy.png')};assert len(existing)==2015
files=[p for folder in sources for p in folder.glob('*_snowy.png')]
assert len(files)==820 and len({p.name for p in files})==820
assert not existing&{p.name for p in files}
records=[]
for p in files:
 assert not p.is_symlink()
 st=p.stat();dest=D/p.name;assert not dest.exists()
 records.append(dict(source=str(p),destination=str(dest),bytes=st.st_size,device=st.st_dev,inode=st.st_ino,mtime_ns=st.st_mtime_ns))
(W/'consolidate_replacements/manifest.json').write_text(json.dumps(records,indent=2))
for r in records:
 src=Path(r['source']);dest=Path(r['destination']);assert not dest.exists()
 os.rename(src,dest)
 st=dest.stat()
 assert (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)==(r['device'],r['inode'],r['bytes'],r['mtime_ns']),str(dest)
 assert not src.exists()
assert len(list(D.glob('*_snowy.png')))==2835
# Update provenance records to follow the moved files.
updated=0
for batch in ['snow_replacements820','snow_approved91']:
 for p in (W/batch/'state/metadata').glob('*_qa.json'):
  q=json.loads(p.read_text());old=Path(q['file']);dest=D/old.name
  if dest.exists() and any(str(old.parent)==str(s) for s in sources):
   q['previous_file']=str(old);q['file']=str(dest);p.write_text(json.dumps(q,indent=2));updated+=1
removed=[]
for folder in sources:
 if not any(folder.iterdir()):folder.rmdir();removed.append(str(folder))
report=dict(moved=820,total_snowy_images=2835,destination=str(D),filenames_unchanged=True,same_file_inodes_sizes_and_mtimes_verified=True,empty_folders_removed=removed,provenance_records_updated=updated)
(W/'consolidate_replacements/verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))

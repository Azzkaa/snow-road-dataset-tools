from pathlib import Path
import sys,os,json,time,gc,hashlib,subprocess,argparse
ROOT=Path('/path/to/user-home/Documents/Codex/2026-11-04/files-mentioned-by-the-user-snow');sys.path.insert(0,str(ROOT/'work/klein_local_20/dependencies'));sys.path.append(str(ROOT/'work/editor_api/dependencies'))
os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1';os.environ['TOKENIZERS_PARALLELISM']='false'
import torch
from PIL import Image
from diffusers import Flux2KleinPipeline,Flux2Transformer2DModel,AutoencoderKLFlux2,FlowMatchEulerDiscreteScheduler,BitsAndBytesConfig
from transformers import Qwen3ForCausalLM,Qwen2TokenizerFast,BitsAndBytesConfig as TextBits
OUT=Path('/path/to/user-home/Documents/Codex/2026-11-11/oka/work/snow_batch_remaining335/state');MODELS=ROOT/'work/klein_local_20/models';dtype=torch.float16
PROMPT=(ROOT/'work/klein_local_20/retry_prompt.txt').read_text()
OUT.joinpath('prompt.txt').write_text(PROMPT)
def write(p,a):p.write_text(json.dumps(a,indent=2)+'\n')
def finite(x):return bool(torch.isfinite(x).all())
p=argparse.ArgumentParser();p.add_argument('--count',type=int,default=335);p.add_argument('--indices',type=str,default='');p.add_argument('--seed-offset',type=int,default=0);args=p.parse_args()
assert torch.cuda.is_available(),'CUDA unavailable: run the GPU launcher in the normal Ubuntu terminal.'
torch.set_num_threads(4);torch.backends.cuda.matmul.allow_tf32=False
rows=json.loads((OUT/'selection.json').read_text());gpu=torch.cuda.get_device_name(0)
print('USING LOCAL GPU:',gpu,flush=True)
write(OUT/'runtime.json',dict(model='black-forest-labs/FLUX.2-klein-4B',transformer_quantization_repo='cukrus/FLUX.2-klein-4B-bnb-nf4',text_encoder_quantization_repo='hlhc/FLUX.2-klein-4B-bnb-4bit',download_revisions=json.loads((ROOT/'work/klein_local_20/download_plan.json').read_text()),device=gpu,compute_dtype='float16',quantization='NF4 double quant',config_adaptations=['BF16 compute changed to FP16 for Turing GPU','Qwen3 rope_theta set to 1000000 from checkpoint rope_parameters for Transformers 4.57 compatibility','VAE kept FP32 with 512px tiling and explicit decode input cast'],torch=torch.__version__,cuda=torch.version.cuda,steps=4,guidance=1.,inference='local CUDA; no hosted inference calls',prompt=PROMPT))
embedsfile=OUT/'prompt_embeds.pt'
if not embedsfile.exists():
 print('Loading 4-bit text encoder on GPU',flush=True)
 enc=Qwen3ForCausalLM.from_pretrained(MODELS/'text_nf4/text_encoder',local_files_only=True,torch_dtype=dtype,quantization_config=TextBits(load_in_4bit=True,bnb_4bit_compute_dtype=dtype,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True),device_map={'':'cuda:0'},attn_implementation='sdpa')
 tok=Qwen2TokenizerFast.from_pretrained(MODELS/'klein_nf4/tokenizer',local_files_only=True)
 for m in enc.modules():
  if hasattr(m,'compute_dtype'):m.compute_dtype=dtype
 with torch.inference_mode():emb=Flux2KleinPipeline._get_qwen3_prompt_embeds(enc,tok,PROMPT,dtype=dtype,device=torch.device('cuda'),max_sequence_length=512)
 assert finite(emb),'Non-finite prompt embedding';torch.save(emb.cpu(),embedsfile)
 print('Prompt encoded:',list(emb.shape),flush=True);del enc,tok,emb;gc.collect();torch.cuda.empty_cache()
emb=torch.load(embedsfile,map_location='cuda',weights_only=True).to(dtype)
config=json.loads((MODELS/'klein_nf4/transformer/config.json').read_text());q=BitsAndBytesConfig.from_dict(config['quantization_config']);q.bnb_4bit_compute_dtype=dtype
print('Loading 4-bit Klein transformer on GPU',flush=True)
trans=Flux2Transformer2DModel.from_pretrained(MODELS/'klein_nf4/transformer',torch_dtype=dtype,quantization_config=q,device_map={'':'cuda:0'},local_files_only=True)
for m in trans.modules():
 if hasattr(m,'compute_dtype'):m.compute_dtype=dtype
vae=AutoencoderKLFlux2.from_pretrained(MODELS/'klein_nf4/vae',torch_dtype=torch.float32,local_files_only=True).to('cuda')
vae.enable_tiling();vae.tile_sample_min_size=512;vae.tile_latent_min_size=64
original_decode=vae.decode
def stable_decode(z,*a,**kw):return original_decode(z.to(vae.dtype),*a,**kw)
vae.decode=stable_decode
sched=FlowMatchEulerDiscreteScheduler.from_pretrained(MODELS/'klein_nf4/scheduler',local_files_only=True)
pipe=Flux2KleinPipeline(scheduler=sched,vae=vae,text_encoder=None,tokenizer=None,transformer=trans,is_distilled=True)
pipe.set_progress_bar_config(disable=True)
print('Pipeline ready; GPU allocated GiB',round(torch.cuda.memory_allocated()/2**30,2),flush=True)
def callback(pipe,step,t,kwargs):
 assert finite(kwargs['latents']),'Non-finite latents'
 print('  inference step',step+1,'/4',flush=True);return kwargs
for r in rows[:args.count]:
 n=r['index'];
 if args.indices and n not in [int(v) for v in args.indices.split(',')]:continue
 if args.seed_offset:r=dict(r,seed=r['seed']+args.seed_offset)
 dest=OUT/'raw'/f'{n:03d}.png'
 if dest.exists():
  print('Already generated',n,flush=True);continue
 assert hashlib.sha256(Path(r['source']).read_bytes()).hexdigest()==r['source_sha256']
 w,h=r['generation_dimensions'];im=Image.open(OUT/r['conditioning']).convert('RGB');torch.cuda.reset_peak_memory_stats();start=time.monotonic()
 write(OUT/'progress.json',dict(target=335,raw_generated=len(list((OUT/'raw').glob('*.png'))),stage='local_GPU_generation',current=n))
 with torch.inference_mode():
  image=pipe(image=im,prompt_embeds=emb,width=w,height=h,num_inference_steps=4,guidance_scale=1.,generator=torch.Generator(device='cuda').manual_seed(r['seed']),callback_on_step_end=callback).images[0]
 image.save(dest);elapsed=time.monotonic()-start
 write(OUT/'metadata'/f'{n:03d}_generation.json',dict(index=n,seed=r['seed'],steps=4,compute_dtype='float16',source_sha256=r['source_sha256'],conditioning_paint_removed_pixels=r['conditioning_paint_removed_pixels'],generation_dimensions=list(image.size),seconds=round(elapsed,2),peak_GPU_allocated_bytes=torch.cuda.max_memory_allocated(),GPU=gpu,raw_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),status='raw_generated_pending_visual_review'))
 print('LOCAL GPU GENERATED',n,'of 335;',round(elapsed,1),'seconds; peak GiB',round(torch.cuda.max_memory_allocated()/2**30,2),flush=True)
 subprocess.run([sys.executable,'/path/to/user-home/Documents/Codex/2026-11-11/oka/work/snow_batch_remaining335/compose.py','--index',str(n)],check=True,cwd=ROOT)
print('LOCAL GENERATION STAGE FINISHED',flush=True)

from pathlib import Path
import json,csv,hashlib,shutil,os,time
B=Path('/path/to/user-home/Documents/Codex/2026-11-11/oka/work/package_pairs')
DESKTOP=Path('/path/to/user-home/Desktop');C=DESKTOP/'full_summer_review_v1/images';S=DESKTOP/'snowy_images';D=DESKTOP/'snowy_clean_pairs'
assert not D.exists(),'Destination already exists; refusing to overwrite'
clean={p.stem:p for p in C.iterdir() if p.is_file() and p.suffix.lower() in ['.jpg','.jpeg','.png']}
snow=sorted(S.glob('*_snowy.png'));assert len(snow)==2835
plan=[]
for p in snow:
 key=p.stem.removesuffix('_snowy');assert key in clean
 plan.append((key,clean[key],p))
assert len({r[0] for r in plan})==len(plan)
total_bytes=sum(c.stat().st_size+s.stat().st_size for _,c,s in plan)
assert shutil.disk_usage(DESKTOP).free>total_bytes+2*10**9
D.mkdir();pairs=D/'pairs';pairs.mkdir()
records=[];start=time.time()
def verified_copy(src,dest):
 before=src.stat();digest=hashlib.sha256()
 with src.open('rb') as f,dest.open('xb') as out:
  while True:
   chunk=f.read(4*1024*1024)
   if not chunk:break
   digest.update(chunk);out.write(chunk)
 shutil.copystat(src,dest)
 after=src.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),f'Source changed while copying: {src}'
 assert dest.stat().st_size==before.st_size
 check=hashlib.sha256()
 with dest.open('rb') as f:
  for chunk in iter(lambda:f.read(4*1024*1024),b''):check.update(chunk)
 assert digest.hexdigest()==check.hexdigest(),f'Copy hash mismatch: {dest}'
 return digest.hexdigest()
for i,(key,c,s) in enumerate(plan,1):
 folder=pairs/key;folder.mkdir()
 ch=verified_copy(c,folder/c.name);sh=verified_copy(s,folder/s.name)
 records.append(dict(pair_id=key,clean=str((folder/c.name).relative_to(D)),snowy=str((folder/s.name).relative_to(D)),clean_sha256=ch,snowy_sha256=sh))
 if i%25==0 or i==len(plan):
  (B/'progress.json').write_text(json.dumps(dict(copied_pairs=i,total_pairs=len(plan),seconds=round(time.time()-start)),indent=2));print('Verified pairs',i,'/',len(plan),flush=True)
with (D/'pairs.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
manifest=json.loads((C.parent/'manifest.json').read_text());selected={c.name for _,c,_ in plan}
provenance=[]
for r in manifest:
 if Path(r['file']).name in selected:
  provenance.append(dict(clean_filename=Path(r['file']).name,collection=r.get('collection'),review_status=r.get('review_status'),source_metadata=r.get('metadata'),sha256=r.get('sha256')))
(D/'source_provenance.json').write_text(json.dumps(provenance,indent=2))
(D/'README.txt').write_text('Clean and snowy image pairs\n\n2,835 matched pairs, 5,670 images.\n\nEach subfolder in pairs/ contains one clean original and its snowy counterpart. Original filenames are preserved. The snowy filename adds _snowy before .png.\n\npairs.csv maps every clean image to its snowy image and records SHA-256 hashes. Every copied file was checked against its source. source_provenance.json retains source dataset and attribution metadata from the clean-image manifest. Retain the applicable source dataset terms when sharing or using the data.\n\nSnow images were generated with FLUX.2 Klein 4B and composited to the source dimensions. They are synthetic weather edits; this packaging step does not certify visual quality or geometry.\n')
assert len(list(pairs.iterdir()))==2835
assert sum(len(list(p.iterdir())) for p in pairs.iterdir())==5670
report=dict(folder=str(D),pairs=2835,images=5670,all_copy_hashes_verified=True,originals_unchanged=True,image_bytes=total_bytes)
(B/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)

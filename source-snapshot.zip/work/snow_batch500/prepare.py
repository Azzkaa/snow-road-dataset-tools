from pathlib import Path
import json, hashlib, shutil, os
os.environ['HF_HUB_OFFLINE']='1'
import torch, numpy as np
from PIL import Image
from transformers import SegformerImageProcessor, SegformerForSemanticSegmentation
BASE=Path('/path/to/user-home/Documents/Codex/2026-11-11/oka/work/snow_batch500')
OLD=Path('/path/to/user-home/Documents/Codex/2026-11-04/files-mentioned-by-the-user-snow')
OUT=BASE/'state'
DEST=Path('/path/to/user-home/Desktop/klein_snow_first500_2026-11-11')
DEST.mkdir(exist_ok=True)
for d in ['inputs','masks','raw','metadata']: (OUT/d).mkdir(parents=True,exist_ok=True)
shutil.copy('/path/to/user-home/Desktop/klein_snow_local_20_v2/prompt_embeds.pt',OUT/'prompt_embeds.pt')
shutil.copy('/path/to/user-home/Desktop/klein_snow_local_20_v2/prompt.txt',OUT/'prompt.txt')
pool=Path('/path/to/user-home/Desktop/full_summer_review_v1')
provenance={r['file']:r for r in json.loads((pool/'manifest.json').read_text())}
sources=sorted(p for p in (pool/'images').iterdir() if p.suffix.lower() in ['.jpg','.jpeg','.png'])[:500]
assert len(sources)==500
torch.set_num_threads(4)
cache=str(OLD/'work/klein_snow_100/model_cache')
model_id='nvidia/segformer-b0-finetuned-ade-512-512'
p=SegformerImageProcessor.from_pretrained(model_id,cache_dir=cache,local_files_only=True)
m=SegformerForSemanticSegmentation.from_pretrained(model_id,cache_dir=cache,local_files_only=True).eval().to('cuda')
ground=[int(i) for i,n in m.config.id2label.items() if n in ['road','sidewalk','earth','grass','field','path','sand','dirt track','land']]
rows=[]
for n,src in enumerate(sources,1):
 im=Image.open(src).convert('RGB');size=im.size
 scale=min(1,1024/max(size));w,h=[max(16,round(v*scale/16)*16) for v in size]
 im=im.resize((w,h),Image.Resampling.LANCZOS);im.save(OUT/'inputs'/f'{n:03d}.png')
 with torch.inference_mode(): logits=m(**p(images=im,return_tensors='pt').to('cuda')).logits
 labels=torch.nn.functional.interpolate(logits,size=(h,w),mode='bilinear',align_corners=False).argmax(1)[0].cpu().numpy()
 mask=np.isin(labels,ground)
 assert mask.any(),f'Empty ground mask {src}'
 Image.fromarray((mask*255).astype('uint8')).save(OUT/'masks'/f'{n:03d}.png')
 rows.append(dict(index=n,source=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),source_dimensions=size,generation_dimensions=[w,h],seed=20261112+n,conditioning=f'inputs/{n:03d}.png',ground_mask=f'masks/{n:03d}.png',conditioning_paint_removed_pixels=0,output_name=src.stem+'_snowy.png',provenance=provenance.get('images/'+src.name)))
 print('Prepared',n,src.name,flush=True)
(OUT/'selection.json').write_text(json.dumps(rows,indent=2))
(DEST/'README.txt').write_text('FLUX.2 Klein 4B local generation, first 500 existing summer files in filename order. PNGs preserve source stems with _snowy. Ground-only semantic composition; generated at up to 1024px then resized to original dimensions. Images require visual screening for residual paint and geometry. Generation records are in '+str(OUT)+'.\n')

from pathlib import Path
import subprocess,json,time,traceback
B=Path(__file__).parent
PY='/path/to/user-home/anaconda3/envs/snow-edit/bin/python'
try:
 with (B/'prepare.log').open('w') as log:
  subprocess.run([PY,'-u',str(B/'prepare.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
 with (B/'generate.log').open('w') as log:
  subprocess.run([PY,'-u',str(B/'generate.py'),'--count','500'],stdout=log,stderr=subprocess.STDOUT,check=True)
 (B/'finished.json').write_text(json.dumps({'status':'generated_pending_visual_review','time':time.time()}))
except Exception:
 (B/'failure.txt').write_text(traceback.format_exc())
 raise

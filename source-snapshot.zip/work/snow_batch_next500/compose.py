from pathlib import Path
import argparse,json,hashlib
import numpy as np
from PIL import Image,ImageFilter
B=Path('/path/to/user-home/Documents/Codex/2026-11-11/oka/work/snow_batch_next500/state')
D=Path('/path/to/user-home/Desktop/klein_snow_next500_2026-11-12')
p=argparse.ArgumentParser();p.add_argument('--index',type=int,required=True);n=p.parse_args().index
r=json.loads((B/'selection.json').read_text())[n-1]
im=Image.open(r['source']).convert('RGB');a=np.array(im)
mask=Image.open(B/r['ground_mask']).resize(im.size,Image.Resampling.NEAREST)
allowed=np.array(mask)>0
alpha=np.array(mask.filter(ImageFilter.GaussianBlur(max(1,im.width/1024))),dtype=np.float32)/255
alpha[~allowed]=0
gen=np.array(Image.open(B/'raw'/f'{n:03d}.png').convert('RGB').resize(im.size,Image.Resampling.LANCZOS))
final=np.rint(alpha[...,None]*gen+(1-alpha[...,None])*a).clip(0,255).astype('uint8');final[~allowed]=a[~allowed]
dest=D/r['output_name'];Image.fromarray(final).save(dest,compress_level=1)
saved=np.array(Image.open(dest));assert not np.any(saved[~allowed]!=a[~allowed])
q=dict(index=n,file=str(dest),dimensions=list(im.size),outside_mask_changed_pixels=0,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),status='pending_visual_review')
(B/'metadata'/f'{n:03d}_qa.json').write_text(json.dumps(q,indent=2))
count=len(list(D.glob('*_snowy.png')))
(B/'progress.json').write_text(json.dumps(dict(target=500,generated=count,current=n,stage='complete_pending_visual_review' if count==500 else 'generating'),indent=2))
print('Saved',dest.name,flush=True)

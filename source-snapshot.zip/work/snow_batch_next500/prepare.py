from pathlib import Path
import json, hashlib, shutil, os
os.environ['HF_HUB_OFFLINE']='1'
import torch, numpy as np


from PIL import Image, ImageFilter, ImageDraw
from transformers import SegformerImageProcessor, SegformerForSemanticSegmentation
BASE=Path('/path/to/user-home/Documents/Codex/2026-11-11/oka/work/snow_batch_next500')
OLD=Path('/path/to/user-home/Documents/Codex/2026-11-04/files-mentioned-by-the-user-snow')
OUT=BASE/'state'
DEST=Path('/path/to/user-home/Desktop/klein_snow_next500_2026-11-12')
DEST.mkdir(exist_ok=True)
for d in ['inputs','masks','raw','metadata']: (OUT/d).mkdir(parents=True,exist_ok=True)
shutil.copy('/path/to/user-home/Desktop/klein_snow_local_20_v2/prompt_embeds.pt',OUT/'prompt_embeds.pt')
shutil.copy('/path/to/user-home/Desktop/klein_snow_local_20_v2/prompt.txt',OUT/'prompt.txt')
pool=Path('/path/to/user-home/Desktop/full_summer_review_v1')
provenance={r['file']:r for r in json.loads((pool/'manifest.json').read_text())}
sources=sorted(p for p in (pool/'images').iterdir() if p.suffix.lower() in ['.jpg','.jpeg','.png'])[500:1000]
assert len(sources)==500
torch.set_num_threads(4)
cache=str(OLD/'work/klein_snow_100/model_cache')
model_id='nvidia/segformer-b0-finetuned-ade-512-512'
p=SegformerImageProcessor.from_pretrained(model_id,cache_dir=cache,local_files_only=True)
m=SegformerForSemanticSegmentation.from_pretrained(model_id,cache_dir=cache,local_files_only=True).eval().to('cuda')
ground=[int(i) for i,n in m.config.id2label.items() if n in ['road','sidewalk','earth','grass','field','path','sand','dirt track','land']]
rows=[]
previous=json.loads(Path('/path/to/user-home/Documents/Codex/2026-11-11/oka/work/snow_batch500/state/selection.json').read_text())
assert not {r['source'] for r in previous}.intersection(map(str,sources))
(OUT/'mask_previews').mkdir(exist_ok=True)
protected=[int(i) for i,label in m.config.id2label.items() if label in ['car','bus','truck','van','person','bicycle','motorbike','building','sky','tree','wall','fence','signboard','streetlight']]
road=[int(i) for i,label in m.config.id2label.items() if label in ['road','path','sidewalk','dirt track']]

for n,src in enumerate(sources,1):
 im=Image.open(src).convert('RGB');size=im.size
 scale=min(1,1024/max(size));w,h=[max(16,round(v*scale/16)*16) for v in size]
 im=im.resize((w,h),Image.Resampling.LANCZOS);im.save(OUT/'inputs'/f'{n:03d}.png')
 # Union of original and mirrored predictions catches asymmetric road omissions.
 probs=[]
 for flip in [False,True]:
  view=im.transpose(Image.Transpose.FLIP_LEFT_RIGHT) if flip else im
  with torch.inference_mode():
   logits=m(**p(images=view,return_tensors='pt').to('cuda')).logits
   prob=torch.nn.functional.interpolate(logits,size=(h,w),mode='bilinear',align_corners=False).softmax(1)[0].cpu().numpy()
  probs.append(prob[:,:,::-1].copy() if flip else prob)
 avg=(probs[0]+probs[1])/2
 labels=avg.argmax(0)
 base=np.isin(probs[0].argmax(0),ground)
 mask=base | np.isin(probs[1].argmax(0),ground)
 # Include uncertain road pixels; never use a blanket lower-image polygon.
 roadprob=avg[road].sum(0)
 protectprob=avg[protected].sum(0)
 hardprotect=np.isin(labels,protected) & (protectprob>.40)
 candidate=(roadprob>.24)&(protectprob<.35)
 mask |= candidate
 # Close narrow road gaps and fill enclosed segmentation holes, keeping objects protected.
 padded=Image.fromarray(np.pad(mask.astype('uint8')*255,4,mode='edge'))
 closed=np.array(padded.filter(ImageFilter.MaxFilter(9)).filter(ImageFilter.MinFilter(9)))[4:-4,4:-4]>0
 flood=Image.fromarray(np.pad(closed.astype('uint8')*255,1))
 ImageDraw.floodfill(flood,(0,0),128)
 holes=np.array(flood)[1:-1,1:-1]==0
 small=holes&(roadprob>.12)&(protectprob<.25)
 mask=(mask|closed|small)&~hardprotect
 overlay=np.array(im).copy();overlay[mask]=(overlay[mask]*.5+np.array([0,210,255])*.5).astype('uint8')
 Image.fromarray(overlay).save(OUT/'mask_previews'/f'{n:03d}.jpg',quality=88)
 (OUT/'metadata'/f'{n:03d}_mask.json').write_text(json.dumps(dict(method='Original and flip SegFormer ensemble; road probability expansion; narrow gap closing; enclosed road-probable holes; protected object exclusion',base_pixels=int(base.sum()),final_pixels=int(mask.sum()),added_pixels=int((mask&~base).sum()),protected_pixels=int(hardprotect.sum()))))
 assert mask.any(),f'Empty ground mask {src}'
 Image.fromarray((mask*255).astype('uint8')).save(OUT/'masks'/f'{n:03d}.png')
 rows.append(dict(index=n,source=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),source_dimensions=size,generation_dimensions=[w,h],seed=20261112+500+n,conditioning=f'inputs/{n:03d}.png',ground_mask=f'masks/{n:03d}.png',conditioning_paint_removed_pixels=0,output_name=src.stem+'_snowy.png',provenance=provenance.get('images/'+src.name)))
 print('Prepared',n,src.name,flush=True)
(OUT/'selection.json').write_text(json.dumps(rows,indent=2))
(BASE/'README.txt').write_text('FLUX.2 Klein 4B local generation, next 500 existing summer files in filename order. PNGs preserve source stems with _snowy. Ground-only semantic composition; generated at up to 1024px then resized to original dimensions. Images require visual screening for residual paint and geometry. Generation records are in '+str(OUT)+'.\n')

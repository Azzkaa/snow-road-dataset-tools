from pathlib import Path
import hashlib,json,os
base=Path('/path/to/user-home/Desktop')
names=['klein_snow_first500_2026-11-11','klein_snow_next500_2026-11-12','klein_snow_batch3_1001-1500','klein_snow_batch4_1501-2000','klein_snow_batch5_2001-2500','klein_snow_final335']
dest=base/'snowy_images'
assert not dest.exists(),f'Destination already exists: {dest}'
files=[]
for name in names:
 folder=base/name
 assert folder.is_dir() and not folder.is_symlink()
 for p in folder.iterdir():
  assert p.is_file() and not p.is_symlink() and p.name.endswith('_snowy.png'),str(p)
  files.append(p)
assert len(files)==2835
assert len({p.name for p in files})==len(files),'Filename collision'
records=[dict(source=str(p),destination=str(dest/p.name),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
log=Path('/path/to/user-home/Documents/Codex/2026-11-11/oka/work/consolidate_snow/manifest.json')
log.write_text(json.dumps(records,indent=2))
dest.mkdir()
for r in records:
 os.rename(r['source'],r['destination'])
for r in records:
 p=Path(r['destination'])
 assert p.stat().st_size==r['bytes']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'],str(p)
assert len(list(dest.glob('*_snowy.png')))==2835
for name in names:
 (base/name).rmdir()
print(json.dumps(dict(folder=str(dest),verified_images=2835,empty_batch_folders_removed=len(names))))

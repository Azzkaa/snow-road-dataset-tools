from pathlib import Path
import os,subprocess,json,hashlib,time
root=Path('/path/to/user-home/Documents/Codex/2026-11-11/oka/work/usb_move');mount=Path('/path/to/external-media/ESD-USB')
assert os.geteuid()==0
expected=json.loads((root/'usb_identity.json').read_text())['blockdevices'][0]
actual=json.loads(subprocess.check_output(['/usr/bin/lsblk','-J','-b','-o','NAME,SIZE,SERIAL,TRAN','/dev/sda'],text=True))['blockdevices'][0]
assert actual['serial']==expected['serial'] and actual['size']==expected['size']==123060879360 and actual['tran']=='usb'
assert subprocess.check_output(['/usr/sbin/blkid','-s','UUID','-o','value','/dev/sda1'],text=True).strip()=='E83F-15C1'
backup=json.loads((root/'existing_usb_backup_verification.json').read_text());assert backup['all_hashes_verified']
paths=set()
for item in backup['files']:
 rel=item['path'];paths.add(rel)
 assert hashlib.sha256((Path(backup['backup'])/rel).read_bytes()).hexdigest()==item['sha256']
 assert hashlib.sha256((mount/rel).read_bytes()).hexdigest()==item['sha256']
current={str(f.relative_to(mount)) for f in mount.rglob('*') if f.is_file() and f.relative_to(mount).parts[0]!='snowy_clean_pairs'}
assert current==paths
assert all((Path('/path/to/user-home/Desktop')/name).is_dir() for name in ['snowy_clean_pairs','snowy_images','full_summer_review_v1'])
print('USB identity and original-file backup verified. Formatting approved USB only.',flush=True)
subprocess.run(['/usr/bin/umount',str(mount)],check=True)
subprocess.run(['/usr/sbin/parted','--script','/dev/sda','mklabel','gpt'],check=True)
subprocess.run(['/usr/sbin/parted','--script','--align','optimal','/dev/sda','mkpart','primary','1MiB','100%'],check=True)
subprocess.run(['/usr/sbin/parted','--script','/dev/sda','set','1','msftdata','on'],check=True)
subprocess.run(['/usr/bin/udevadm','settle'],check=True)
subprocess.run([str(root/'tools/extracted/usr/sbin/mkfs.exfat'),'-L','ESD-USB','/dev/sda1'],check=True)
print('FORMAT COMPLETE',flush=True)

from pathlib import Path
import time,json,os,statistics
import psutil
r=Path(__file__).resolve().parent;pid=22379;proc=psutil.Process(pid);born=proc.create_time();p=json.loads((r/'progress.json').read_text());started=(r/'progress.json').stat().st_mtime-p['seconds'];old=[int(x) for x in Path('/sys/block/sda/stat').read_text().split()];last=time.time();rates=[]
while True:
 now=time.time();p=json.loads((r/'progress.json').read_text())
 try:
  vals=[int(x) for x in Path('/sys/block/sda/stat').read_text().split()];rate=max(0,(vals[6]-old[6])*512/(now-last)/1e6);old=vals;last=now
  if rate>0.01:rates.append(rate);rates=rates[-12:]
 except Exception:rate=0
 alive=psutil.pid_exists(pid) and psutil.Process(pid).create_time()==born and psutil.Process(pid).status()!=psutil.STATUS_ZOMBIE
 state='complete' if p['phase']=='complete' else ('running' if alive else 'stopped')
 (r/'monitor.json').write_text(json.dumps({'state':state,'elapsed_seconds':now-started,'usb_write_mb_s':statistics.median(rates) if rates else 0,'last_checked':now}))
 if state=='complete':break
 if not alive:
  if p['phase']!='complete':
   p['phase']='transfer_stopped_check_log';(r/'progress.json').write_text(json.dumps(p))
  break
 time.sleep(5)

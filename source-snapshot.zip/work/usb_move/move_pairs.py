from pathlib import Path
import os,json,hashlib,shutil,time,csv
root=Path(__file__).resolve().parent;src=Path('/path/to/user-home/Desktop/snowy_clean_pairs');mount=Path('/path/to/external-media/ESD-USB');dst=mount/'snowy_clean_pairs';start=time.time()
assert mount.is_mount() and src.is_dir() and not src.is_symlink() and not dst.exists()
files=sorted(f for f in src.rglob('*') if f.is_file());total=sum(f.stat().st_size for f in files)
assert shutil.disk_usage(mount).free>total+512*1024**2
assert all(f.stat().st_size<2**32-1 for f in files)
expected={}
for row in csv.DictReader((src/'pairs.csv').open()):
 expected[row['clean']]=row['clean_sha256'];expected[row['snowy']]=row['snowy_sha256']
records=[];done=0;dst.mkdir()
def status(phase,index):
 (root/'progress.json').write_text(json.dumps({'phase':phase,'files':index,'total_files':len(files),'bytes':done,'total_bytes':total,'seconds':time.time()-start,'destination':str(dst)}))
status('copying',0)
for i,f in enumerate(files,1):
 rel=f.relative_to(src);d=dst/rel;d.parent.mkdir(parents=True,exist_ok=True);stamp=f.stat();h=hashlib.sha256()
 with f.open('rb') as fi,d.open('xb') as fo:
  while True:
   b=fi.read(4*1024**2)
   if not b:break
   fo.write(b);h.update(b)
  fo.flush();os.fsync(fo.fileno())
 digest=h.hexdigest();assert str(rel) not in expected or digest==expected[str(rel)],f'Source differs from pair manifest: {rel}'
 hd=hashlib.sha256()
 with d.open('rb') as fd:
  for b in iter(lambda:fd.read(4*1024**2),b''):hd.update(b)
 assert digest==hd.hexdigest() and d.stat().st_size==stamp.st_size
 assert f.stat().st_size==stamp.st_size and f.stat().st_mtime_ns==stamp.st_mtime_ns
 records.append({'relative_path':str(rel),'bytes':stamp.st_size,'sha256':digest,'source_mtime_ns':stamp.st_mtime_ns});done+=stamp.st_size
 if i%10==0:status('copying_and_verifying',i)
 if i%100==0:print(i,len(files),round(done/1e9,2),'GB',flush=True)
(root/'verified_manifest.json').write_text(json.dumps(records,indent=2));assert mount.is_mount()
assert {str(f.relative_to(src)) for f in src.rglob('*') if f.is_file()}=={r['relative_path'] for r in records}
for r in records:
 f=src/r['relative_path'];assert f.stat().st_size==r['bytes'] and f.stat().st_mtime_ns==r['source_mtime_ns']
status('verified_removing_local_paired_copy',len(files))
# Only the fully copied and verified paired folder is removed. Other datasets and ZIPs remain.
shutil.rmtree(src);src.symlink_to(dst,target_is_directory=True)
result={'destination':str(dst),'desktop_shortcut':str(src),'files':len(files),'images':len(expected),'pairs':len(expected)//2,'bytes_freed':total,'all_sha256_verified':True,'other_local_folders_and_archives_removed':False,'seconds':time.time()-start}
(root/'verification.json').write_text(json.dumps(result,indent=2));status('complete',len(files));print(json.dumps(result),flush=True)

from pathlib import Path
import os,json,hashlib,shutil,time,csv,subprocess
root=Path(__file__).resolve().parent;desktop=Path('/path/to/user-home/Desktop');mount=Path('/path/to/external-media/ESD-USB');names=['full_summer_review_v1','snowy_images','snowy_clean_pairs'];start=time.time()
assert mount.is_mount() and shutil.disk_usage(mount).free>50*10**9
backup=json.loads((root/'existing_usb_backup_verification.json').read_text())
# Restore exactly the USB's original files, without executing any of them.
for item in backup['files']:
 f=Path(backup['backup'])/item['path'];d=mount/item['path'];d.parent.mkdir(parents=True,exist_ok=True)
 
 if not d.exists():shutil.copyfile(f,d)
 with d.open('rb') as stream:os.fsync(stream.fileno())
 assert hashlib.sha256(d.read_bytes()).hexdigest()==item['sha256']
(root/'usb_originals_restored.json').write_text(json.dumps({'files':len(backup['files']),'all_hashes_verified':True}))
expected={}
for row in csv.DictReader((desktop/'snowy_clean_pairs/pairs.csv').open()):
 for key in ['clean','snowy']:
  expected[('snowy_clean_pairs',row[key])]=row[key+'_sha256']
  name=Path(row[key]).name
  expected[('snowy_images' if key=='snowy' else 'full_summer_review_v1',name if key=='snowy' else 'images/'+name)]=row[key+'_sha256']
jobs=[]
for name in names:
 src=desktop/name;assert src.is_dir() and not src.is_symlink()
 jobs.extend((name,f,f.relative_to(src)) for f in sorted(src.rglob('*')) if f.is_file())
total=sum(f.stat().st_size for _,f,_ in jobs);assert shutil.disk_usage(mount).free>total+512*1024**2
records=[];done=0
def status(phase,i):
 temp=root/'progress.tmp';temp.write_text(json.dumps({'phase':phase,'files':i,'total_files':len(jobs),'bytes':done,'total_bytes':total,'seconds':time.time()-start,'destination':str(mount),'folders':names,'local_images_removed':phase=='complete'}));temp.replace(root/'progress.json')
status('copying_and_verifying',0)
for i,(name,f,rel) in enumerate(jobs,1):
 dst=mount/name/rel;dst.parent.mkdir(parents=True,exist_ok=True);stamp=f.stat();h=hashlib.sha256()
 with f.open('rb') as fi,dst.open('wb') as fo:
  for b in iter(lambda:fi.read(4*1024**2),b''):fo.write(b);h.update(b)
  fo.flush()
 digest=h.hexdigest();assert (name,str(rel)) not in expected or digest==expected[(name,str(rel))]
 assert dst.stat().st_size==stamp.st_size
 assert f.stat().st_size==stamp.st_size and f.stat().st_mtime_ns==stamp.st_mtime_ns
 records.append({'folder':name,'path':str(rel),'bytes':stamp.st_size,'sha256':digest,'mtime_ns':stamp.st_mtime_ns});done+=stamp.st_size
 if i%10==0:status('copying_and_verifying',i)
 if i%100==0:print(i,len(jobs),round(done/1e9,2),'GB',flush=True)
status('synchronizing_usb_writes',len(jobs))
subprocess.run(['/usr/bin/sync','-f',str(mount)],check=True)
done=0
for i,r in enumerate(records,1):
 hd=hashlib.sha256()
 with (mount/r['folder']/r['path']).open('rb') as fd:
  for b in iter(lambda:fd.read(4*1024**2),b''):hd.update(b)
 assert hd.hexdigest()==r['sha256']
 done+=r['bytes']
 if i%10==0:status('verifying_usb_copies',i)
(root/'all_folders_verified_manifest.json').write_text(json.dumps(records,indent=2))
assert mount.is_mount()
for name in names:
 assert {str(f.relative_to(desktop/name)) for f in (desktop/name).rglob('*') if f.is_file()}=={r['path'] for r in records if r['folder']==name}
for r in records:
 f=desktop/r['folder']/r['path'];assert f.stat().st_size==r['bytes'] and f.stat().st_mtime_ns==r['mtime_ns']
status('all_verified_removing_local_copies',len(jobs))
for name in names:
 shutil.rmtree(desktop/name);(desktop/name).symlink_to(mount/name,target_is_directory=True)
result={'folders':names,'destination':str(mount),'files':len(jobs),'all_sha256_verified':True,'bytes_freed':total,'desktop_shortcuts_preserve_paths':True,'usb_original_files_restored_and_verified':True,'seconds':time.time()-start}
(root/'verification.json').write_text(json.dumps(result,indent=2));status('complete',len(jobs));print(json.dumps(result),flush=True)
